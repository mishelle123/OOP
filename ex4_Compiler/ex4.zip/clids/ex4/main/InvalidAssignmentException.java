package clids.ex4.main;
import java.io.IOException;

@SuppressWarnings("serial")
public class InvalidAssignmentException extends IOException{

}
