package clids.ex4.toolbox;
import java.io.IOException;

@SuppressWarnings("serial")
public class MissingBracketException extends IOException{

}
