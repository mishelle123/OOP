package clids.ex4.variables;

import java.io.IOException;

@SuppressWarnings("serial")
public class IlligalVariableException extends IOException{

}
