package clids.ex4.variables;

import java.io.IOException;

@SuppressWarnings("serial")
public class illigalVariableNameException extends IOException {

}
