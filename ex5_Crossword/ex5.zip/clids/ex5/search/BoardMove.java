package clids.ex5.search;

public interface BoardMove {
	// This is a marker interface for moves compatible with search board
	// Usage of this interface allows to associate board with compatible
	// moves
}
